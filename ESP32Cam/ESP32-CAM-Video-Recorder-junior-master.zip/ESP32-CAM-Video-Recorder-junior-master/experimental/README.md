
This folder contains experimental stuff

Buy me a Double Mochaccino half caf, non fat, with extra cream on the side? https://ko-fi.com/jameszah


The folder 07x_FTP is a the version 7 discussed in the main readme, but it adds an ftp server host.

Set up your ftp client in passive mode and connect to the ip address of the esp32.
