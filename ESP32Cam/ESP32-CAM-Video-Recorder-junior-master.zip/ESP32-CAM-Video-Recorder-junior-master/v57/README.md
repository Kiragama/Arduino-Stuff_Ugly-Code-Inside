
new Version with http file transfer to copy your videos from the esp32 sd to your browser on your Windows/Andriod/etc computer.

You need all the files from the v57 folder, plus the config.txt file.

More discussion later ...

Buy me a Double Mochaccino half caf, non fat, with extra cream on the side? https://ko-fi.com/jameszah
